Tata Group – Forage Virtual Experience Project

This folder contains all completed tasks from the Tata Data Analytics and AI-powered Collections Strategy virtual experience.

1. EDA_Summary_Report.pdf – Data quality checks and early risk insights.
2. Credit_Risk_Modeling_Plan.pdf – Predictive modeling approach and evaluation plan.
3. Credit_Risk_Business_Report.pdf – Business recommendations and ethical AI analysis.
4. AI_Collections_System_Deck.pptx – Executive-level AI collections system overview.

Saved for future portfolio, internship, and interview use.